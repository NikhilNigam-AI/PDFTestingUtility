import csv
import os
import subprocess
import pandas as pd

working_dir ="/Users/nikhil/Documents/tech/PDF Forms/APT/python/"
path_to_input = "/Users/nikhil/Documents/tech/PDF Forms/APT/python/jobsbatch.csv"
# path_to_pdftester = "java -jar '"+"/Users/nikhil/Documents/tech/PDF Forms/APT/Pdftesting.jar"+"' "
path_to_pdftester = "/Users/nikhil/Documents/tech/PDF Forms/APT/Pdftesting.jar"
path_to_config=''

def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):  # If Machine is running on Windows, use cls
        command = 'cls'
    os.system(command)

print('.job started')            
df = pd.read_csv(path_to_input) 
for ind in df.index:
    # clearConsole()
    print('.testing '+ df['Name'][ind])
    configFile = df['job-xml'][ind]
    df['Status'][ind] = "Uknown"
    df['Result'][ind] = "Uknown"
    
    if configFile:
        cmd = "java -jar '"+path_to_pdftester +"' '"+ path_to_config + configFile+"'"
        os.system(cmd)
        result = subprocess.check_output(cmd, shell=True, text= True)   
        if 'Test completed' in result:
            result = result.split("Test completed",1)[1]
            if 'RESULT = Passed' in result:
                  df['Result'][ind] = result.split("RESULT = Passed", 1)[0]
                  df['Status'][ind]= "Passed"
            if 'RESULT = Failed' in result:
                  df['Result'][ind] = result.split("RESULT = Failed", 1)[0]
                  df['Status'][ind] = "Failed"
print('.updating results')
df.to_csv(path_to_input,index=False)
print('.job completed')